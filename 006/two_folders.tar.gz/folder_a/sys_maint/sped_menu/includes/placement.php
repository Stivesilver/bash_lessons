<?php
    if ($student->get('ecflag') == 'Y') {
        return array('menutext'=>'Educational Environment');
    }
?>