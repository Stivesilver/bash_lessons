<?php
	if (IDEACore::disParam(53) != 'Y') {
	    return array('condition'=>false);
	}
?>