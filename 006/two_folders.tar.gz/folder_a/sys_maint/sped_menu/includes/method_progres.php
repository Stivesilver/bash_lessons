<?php
	if (IDEACore::disParam(41) != 'Y') {
	    return array('condition'=>false);
	}
?>