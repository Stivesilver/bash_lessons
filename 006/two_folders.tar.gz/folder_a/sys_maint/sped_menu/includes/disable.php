<?php
    return array('condition'=>false);
?>