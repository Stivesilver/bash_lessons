<?php
    
    Security::init();

    $list = new ListClass();


?>
