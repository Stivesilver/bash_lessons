<?php
	Security::init();
?>
<script>
	parent.selectNext();
</script>
